# AIC Ololepo Youths — Projects & Contributions Manager

This is a static demonstration prototype for previewing the interface.

## Deploy as a static site with Cloudflare Pages

1. Create a new GitHub repository named `aic-ololepo-youths`.
2. Upload `index.html` and this `README.md` to the repository root.
3. In Cloudflare, open **Workers & Pages → Create → Pages → Connect to Git**.
4. Select the repository.
5. Use no build command. Set the build output directory to `/` (or leave the static-site output directory as the repository root if prompted).
6. Deploy and open the generated `*.pages.dev` URL.

## Important security notice

This is a front-end demo only. It does not include secure authentication, a server/database, role enforcement, audit logging, or persistent storage. Records entered in the demo are held in browser memory and can be lost on refresh. Do not use it for real member or financial records.

Before production use, replace the demo with a database-backed application, implement authentication and server-side authorization, configure row-level security, and test access controls.
